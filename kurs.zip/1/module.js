// InitModule
function InitModule()
{
}

// ShutdownModule
function ShutdownModule()
{
}
